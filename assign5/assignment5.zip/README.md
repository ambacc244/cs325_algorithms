Following commend lines allow to run wrestler.cpp file.
Assume, there is wrestler.txt file in the same directory.
txt file name should be wrestler.txt.

Command lines to run activity.cpp
	g++ -o run wrestler.cpp
	./run

Then, it will return wrestler.out file
